module.exports.config = {
    name: "fire",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Hammad",
    description: "5 Translation: Constantly tag a friend for the bar\nThat person can be called soul calling",
    commandCategory: "nsfw",
    usages: " please @mention",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
    var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("To @mention 1 person you love ", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("Mera Puter ab dekh tere sath hota kia hai💋");
setTimeout(() => {a({body: "TERI BEHN KI CHUT FAT GAYI NA 🐼 🐬 (Y) TERIII MAA KO JIBI ROD KA TOP RANDI BANA KE 😚🐬 । 🥰।" + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "‎T3R1 B3H4N (y) 👙❌ K4 PU7D44 :P M4R99 +) (+ R444ND1!! /-( K44 &#( 83CH44 #$-?.." + " " + name, mentions: arraytag})}, 4000);
setTimeout(() => {a({body: "‎TERI MAA KO ?!&@ NAGGA KAR KE CHODUGGA 🐬 ---TERI KHALA KI XCHUT PE _#:LAAT MARU (Y) 🐬 🖕🏻" + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: ".fyt‎TERE MAA KO HIJRA BANA KE CHODU GGA 🐬 (Y) TERII CHHOTI BALI BEHEN KA BHOSRA PE LAAT MARU" + " " + name, mentions: arraytag})}, 6000);
setTimeout(() => {a({body: "ARE MADHAR CHOD TERI BEHEN KI MKC 🐬(Y) TERI MA KO BICH ROD PE LETA KE CHODU" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "TERII KHALA KI GAND PE MUT DU 🐬(Y) TERII BARI BEHEN KO CHOD KE DAFNA DU " + " " + name, mentions: arraytag})}, 8000);
setTimeout(() => {a({body: "TERI NANI KI GAND PE CHAPPAL SE MARU 🐬 (Y) ARE JA MADHAR CHOD FACE😘" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "TERI BEHEN KO.LE AA BETA GAMAR 🐬 (Y) 😚 TERI BARI BAALI  BEHEN KO LE AA RANDI KE" + " " + name, mentions: arraytag})}, 10000);
setTimeout(() => {a({body: "TERI MAA KO  HIJRA BANA KE CHODUGA 😚🐬 (Y) R3NND1111 K444 B3CH444" + " " + name, mentions: arraytag})},11000);
setTimeout(() => {a({body: "TERI BUWA KI GAND PE HATORA DAAL DU 😚🌏🐬 TERI MAA KO PUCHH CHUDAY KISE KEHTE HAI" + " " + name, mentions: arraytag})},12000);  
setTimeout(() => {a({body: "TERI BEHN KI CHUT FAT GAYI NA 🐼 🐬 (y) TERI BEHN KA BHOSRA FAT GYI RE MADHAR CHOD" + " " + name, mentions: arraytag})},13000);
  setTimeout(() => {a({body: "TERI BEHN KI GAAND BAHUT CUTE HAI BHAI 🤤😚🐬 TERI AMMI JAAN KA BHOSRA FAARU 🐬😚" + " " + name, mentions: arraytag})},14000);
  setTimeout(() => {a({body: "BHAGNA MAT TERI BEHEN KI MKC 🤤🐬 (Y) TERI MKC TBK MADHAR 🐬🥀" + " " + name, mentions: arraytag})},15000);
  setTimeout(() => {a({body: ".fyt2 733RR111 4M4 K4 PHU774 🐬 :P M31N  👙 🐟🐟🐟🦈🐡M3R1 L4L L4N6" + " " + name, mentions: arraytag})},16000);
  setTimeout(() => {a({body: "-T3R!!! B33H3N R33ND!!! 🐟 K111 B3CH1!! 👙🐟 " + " " + name, mentions: arraytag})},17000);
  setTimeout(() => {a({body: "T3R11 B33H4NN K11!!! 🦈💸 🦈 G3ND C|-|0D 🐡🐬 DOUU G44 💸🐡🐬" + " " + name, mentions: arraytag})},18000);
  setTimeout(() => {a({body: "TERI AMA KA 🐬👙🐡🐬👙 BSDKA MAROU 💸 🐡 TEXI KII OLAD 👙" + " " + name, mentions: arraytag})},19000);
  setTimeout(() => {a({body: "TTERI BAHN KO CHODD CHOOD KY 🐬2💸👙🐡 RANDI BNA DOU GA" + " " + name, mentions: arraytag})},20000);
  setTimeout(() => {a({body: "TERI AMA KA BOOBS 💸🐡🐬👙🐡 MAIN LAND DOU APNA 🐬🐡" + " " + name, mentions: arraytag})},21000);
  setTimeout(() => {a({body: "TERI BAHN KA BOOBS CHUSU 💸🐟🐬 AUR US MAIN APNA 💸🐬👙 LAND DOU 🐟👙🐡😆" + " " + name, mentions: arraytag})},22000);
  setTimeout(() => {a({body: "TERI BAHN KI LEGS UTHA KY 🐟🐡💸🐬🐡 PHUDA MAIN 🐟🐡👙🐡👙 LAND DOU 🐟👙💸👙💸" + " " + name, mentions: arraytag})},23000);
  setTimeout(() => {a({body: ".fyt3 TERI BAHN KI 🐟💸🐬💸🐬 CHUDAI KEROU 🐟💸🐡💸🐡 AUR TERI BAHN KA PHUDA PUSH KEROU GQ 🐟" + " " + name, mentions: arraytag})},24000);
  setTimeout(() => {a({body: "TERI BAHN 🐟👙🐬 KO GANDU BNA DOU GA 🐟🐬💸🐬 TERI BAHN KO TEXI BNA DOU 🐟🐬🐡🐬 GA" + " " + name, mentions: arraytag})},25000);
  setTimeout(() => {a({body: "🐬💸🐡TERI AMA KO BAHN🐬🐟👙  CHOD BNA DOU 🐬👙💸 GA" + " " + name, mentions: arraytag})},26000);
  setTimeout(() => {a({body: "APPNII BBAHAN KO BAJ 🐟3💸3👙RRANDI KA BACHA 🐟🐬🐡👙2" + " " + name, mentions: arraytag})},27000);
  setTimeout(() => {a({body: "🤣TTER!!! DIIDD111 KK44 PHUDA MAROU GA 👙🐟🦈 TAILL LGA KY 🐬🐬🐬" + " " + name, mentions: arraytag})},28000);
  setTimeout(() => {a({body: "GANDUU KA BACHA 🦈🐡🐬 TEXI KA BACHA 👙🦈 MMADER CHOOD 🐟" + " " + name, mentions: arraytag})},29000);
  setTimeout(() => {a({body: ".fyt👙🐟🦈🐡🐬 TERI BAHN KA PHUDA MAIN LORA DOU 🐟🐡🐬" + " " + name, mentions: arraytag})},30000);
setTimeout(() => {a({body: "BBBBBBBBBBBAAAAAAHHHHHHHAAAAAAAAANNNNNNNNNNNNNNNNNNNCCCCCCHHHHHHOOOOOOOOODDDDDDDD" + " " + name, mentions: arraytag})},31000);
 setTimeout(() => {a({body: "TERI BEHN KI CHUT FAT GAYI NA 🐼 🐬 (Y) TERIII MAA KO JIBI ROD KA TOP RANDI BANA K"  + name, mentions: arraytag})},32000);
  setTimeout(() => {a({body: "T3R1 B3H4N (y) 👙❌ K4 PU7D44 :P M4R99" + " " + name, mentions: arraytag})},33000);
  setTimeout(() => {a({body: "TERI MAA KO ?!&@ NAGGA KAR KE CHODUGGA 🐬 (Y) (/+---TERI KHALA KI XCHUT PE _#)&#)@;@:LAAT MARU" + " " + name, mentions: arraytag})},34000);
  setTimeout(() => {a({body: "TERE MAA KO HIJRA BANA KE CHODU GGA 🐬 (Y) TERII CHHOTI" + " " + name, mentions: arraytag})},35000);
  setTimeout(() => {a({body: "ARE GAMAR MADHAR CHOD TERI BEHEN KI MKC 🐬(Y) TERI MA KO BICH ROD PE LETA KE CHODU" + " " + name, mentions: arraytag})},36000);
  setTimeout(() => {a({body: "TERII KHALA KI GAND PE MUT DU 🐬(Y) TERII BARI BEHEN KO CHOD KE DAFNA DU." + " " + name, mentions: arraytag})},37000);
  setTimeout(() => {a({body: "TERI NANI KI GAND PE CHAPPAL SE MARU." + " " + name, mentions: arraytag})},38000);
  setTimeout(() => {a({body: "ARE JA MADHAR CHOD FACE।" + " " + name, mentions: arraytag})},39000);
  setTimeout(() => {a({body: "TERI BEHEN KO.LE AA BETA GAMAR 🐬 (Y) 😚 TERI BARI BAALI  BEHEN KO LE AA RANDI KE" + " " + name, mentions: arraytag})},40000);
  setTimeout(() => {a({body: "TERI MAA KO  HIJRA BANA KE CHODUGA 😚🐬 (Y) R3NND1111 K444 B3CH444" + " " + name, mentions: arraytag})},41000);
  setTimeout(() => {a({body: "TERI BUWA KI GAND PE HATORA DAAL DU " + " " + name, mentions: arraytag})},42000);
  setTimeout(() => {a({body: "TERI MAA KO PUCHH CHUDAY KISE KEHTE HAI. ।" + " " + name, mentions: arraytag})},43000);
  setTimeout(() => {a({body: "TERE MAA KO HIJRA BANA KE CHODU GGA" + " " + name, mentions: arraytag})},44000);
  setTimeout(() => {a({body: "T3R!!! B33H3N R33ND!!! 🐟 K111 B3CH1!! " + " " + name, mentions: arraytag})},45000);
  setTimeout(() => {a({body: "TERI BUWA KI GAND PE HATORA DAAL DU " + " " + name, mentions: arraytag})},46000);
  setTimeout(() => {a({body: "TERI BEHN KI GAAND BAHUT CUTE HAI BHAI 🤤😚🐬 TERI AMMI JAAN KA BHOSRA FAARU" + " " + name, mentions: arraytag})},47000);
  setTimeout(() => {a({body: "BHOSRA FAT GYI RE MADHAR CHOD" + " " + name, mentions: arraytag})},48000);
  setTimeout(() => {a({body: "TERI AMA KA 🐬👙🐡🐬👙 BSDKA MAROU 💸" + " " + name, mentions: arraytag})},49000);
}