module.exports.config = {
    name: "war",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "... - Long LTD",
    description: "Fire broke the boxchat",
    commandCategory: "group",
    usages: "bold Fire",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("T3R9 B99P BOT 3NT3R S9L3 APN3 B99P S3 JUB99N L9D9Y3G9🤞🏻👅👅");
setTimeout(() => {a({body: " BOT KO G9LI D3N3 W9LO TUMH9RII B9HN KII (+)🙊💋" })}, 3000);
setTimeout(() => {a({body: " T3RII M99 BHOSD99 F99D KR F3KH DUNG9 S9L33 H9WB99Z T9TT3💋🤣"})}, 5000);
setTimeout(() => {a({body: " T3RII M99 K3 BHOSD33 M3 MOOT DUNG99 M9RCHOXDD😜💔" })}, 7000);
setTimeout(() => {a({body: " T3RII M9 KI (+) R9ND K3 B9XH33🤚🏻💋" })}, 9000);
setTimeout(() => {a({body: " T3RII B9HN KO YHI P979K KR CHOD DUNG99 S9L3😈😍" })}, 12000);
setTimeout(() => {a({body: " T3RI B9HN KI G9ND P3 LOD9 F3KH KR M9RUNG9 S9L3😈👿" })}, 15000);
setTimeout(() => {a({body: " T3RII DIDI KI XHUTT M3 LOD9 D3KR TOD DUNG9 S9L3" })}, 17000);
setTimeout(() => {a({body: " 73RII BH9NN K0 PR36N377 KRUU S9L3💋❤" })}, 20000);
setTimeout(() => {a({body: "T3RII M99 K99 BHOXD99 F99D DUNG99 B9HN K3 LOD33😂💋🤣" })}, 23000);
setTimeout(() => {a({body: " T3RII M99 K99 BHOXD99 F99D DUNG99 B9HN K3 LOD33😋💋" })}, 25000);
setTimeout(() => {a({body: " T3RII BH9N PR3GN37 HO GYII M3R3 L9ND S3 XHUDK3💋❤" })}, 28500);
setTimeout(() => {a({body: "R99ND BN99 DUN699 99J 73RII BH9N K0 S9L3💋❤" })}, 31000);
setTimeout(() => {a({body: "T3RI B9HN K9 BHOSD99 KH99 J99UNG9 S9L3 🙊💋😈" })}, 36000);
setTimeout(() => {a({body: " T3RI DIDI KO 9PN3 KH9D3 LUND PR B1TH4DUNG4🤣 🍷😂🤣" })}, 39000);
setTimeout(() => {a({body: " T3RI DIDI KO 9PN3 MOT3 LUND PR XHODUNG99💋❤" })}, 40000);
setTimeout(() => {a({body: " T3RII M9 K9 BHOSD99 NOCH LUNG99🤣😂💋" })}, 65000);
setTimeout(() => {a({body: " T3RI B9HN KI XHU7 M3 H99TH D9LKKR USKI B9CHH9D9NNII B9H99R KH33CH LUNG99😂😅" })}, 70000);
setTimeout(() => {a({body: " T3RII L9NGDII M99 KII CHUTT P3 LOD99 F3KH KR M9RU🤣🥳🥳😂" })}, 75000);
setTimeout(() => {a({body: " T3RII M99 K3 MUH M3 F9TT9 C9NDOM LG9 KR LUND D9LUNG9😂😂" })}, 80000);
setTimeout(() => {a({body: " T3RII B9HN K3 BHOSD33 M3 GHUSH J9UNG9 M9DRCHOD😝🤣" })}, 85000);
setTimeout(() => {a(" T3RI B9HN KII (+) K99 SIZ3 BT9N99💋😂")} , 90000);
setTimeout(() => {a({body: "M9DRCHOD H9W99B9Z T9TT3 COM3DY KR RH9😂😂" })}, 95000);
setTimeout(() => {a({body: "T3RI B9HN KI B9CHH3D9NNNI M3 LUND D3KR USKI B9CH9D9NNI F99D DUNG99💋💋" })}, 100000);
setTimeout(() => {a({body: " T3RII M99 KI S9DII XHUTT PR NIMMBU NICHOD KR RUS NIK9LUNG9💆‍♂️😈❤" })}, 105000);
setTimeout(() => {a({body: " T3RI B9HN KI CHOTI B9DI BOOBS PR LOD99 F3KH KR M9RUNG9 R9NDII K3😈💋"})} , 115000);
setTimeout(() => {a({body: "OK T3R9 B99P J9 RH9 9B RON9 M9T GW4R S4L3 😈💋"})} , 120000);
setTimeout(() => {a({body: " TERY BAJI KE CHUT KISI RANDI MA KA BACHY TERY MA KAA BHSDAA FADUU 😂😈💩" })}, 3000);
setTimeout(() => {a({body: " KI51 RA9D1 M9 K9 BA5H6Y 73R6Y M9 K3 5HU7 LU9 M9RO9 73R6Y GA9D M3I9 KI51 CHU76YI9 M9 K3 UL9D😘🌍😈✨"})}, 5000);
setTimeout(() => {a({body: " T3RY AM9 K9 BH9SD9 F9DU K151 RA9D1 M9 K9 B95H9😈💩" })}, 7000);
setTimeout(() => {a({body: " HERAA MANDI KE.UALD TERY MA KA 4THA YAR HO MEIN KSIS KUTY MA KA BACHY 😂😈💩" })}, 9000);
setTimeout(() => {a({body: " HERAA MANDI KE.UALD TERY MA KA 4THA YAR HO MEIN KSIS KUTY MA KA BACHY 😂😈💩" })}, 12000);
setTimeout(() => {a({body: " NON STOP FYTERR AP KA MAMA KA YAR AARYAN AWRA😂🌍😘 AJ AP KE MA KE CHUT MARNA A RHA TERY BAI KE PHUDYY MEIN LULL KISI RAMDI MA KA DRYA BACHY TERY MA DE OHUDY CHAA JOHNY UNCLE DA LUN KISI GASHTYE MA DEYA BACHYA 😈😡🧸💩" })}, 15000);
setTimeout(() => {a({body: " 😈[[=BHEAN KA LODA TERY MAAA KE CHUTT KISIS CHUTYIA MA KA BACHY=]]💩" })}, 19000);
setTimeout(() => {a({body: " KISI GANDU MA KA BACHY :-)🧸 TERY MA KE CHUT KIS RANDI MA KA BACHY :,-) BHENA KA LODAA KISI SASTY MA KA BACHY :-P😈" })}, 22000);
setTimeout(() => {a({body: " TERY BAI KE CHUT 😆😈 TERY AMA KA BHOSDA UFF US KEIN HABSHYE KA LUN😆😈 TERY CHOTY BAI KE CHUT KEIN LUL KISI RANDI DEYA BACYHYA 8-)😍😘" })}, 25000);
setTimeout(() => {a({body: " K4R 9A T6YP3 :-*😀🦋 BHE9 K9 L9D9 😀🦋 73RY M9 K3 CH4U7 59 PA9I 9IK9L0N 😀🦋 K1SI R9D1 M9 D36Y9 BA5H6Y9🦋😀" })}, 28000);
setTimeout(() => {a({body: "  😆😈 TERY AMA KA BHOSDA UFF US KEIN HABSHYE KA LUN😆😈 TERY CHOTY BAI KE CHUT KEIN LUL KISI RANDI DEYA BACYHYA 8-)😍😘" })}, 30000);
setTimeout(() => {a({body: " K151 Y973EM M9 D3Y9 BA5H6Y 73R6Y K9 K3 5HU7 M3I9 LU9 KI51 RA9D1 D36Y BA5H6Y:-)😂 73RY B9J1 K3 5HU7 M319 LU9 BH39 K9 L0D9 8-)😘" })}, 62000);
setTimeout(() => {a({body: " TERYYY AMAAAA KAAAA BOBEXXXX KOOOO LALLLLL KRONNNN RANDIIII MAAAAA KAAAAA BACHYYY😈😂" })}, 65000);
setTimeout(() => {a({body: " :-)😈M07H3R FU9K😂😆 734RY BA9J1 K3 5HU7 M319 LU9 :-O💋 73RY BAL9J1 K3 BR9Z3R M319 P91 DAL09 😆💋" })}, 69000);
setTimeout(() => {a({body: " T3R111  M44 K33 BURR M33 H4THH D4LK3 B4CH3DANI NIK4L DUNG4 B4H4N K3 LAWDE😂😈😘" })}, 72000);
setTimeout(() => {a({body: " MADARCHOADDD KEEE ULADDD :-D😈 BAPPPP BOLLL DAA NAHI TO TERY MAA KEEE CHUTT FADD DON GAAA :,-)😈" })}, 75000);
setTimeout(() => {a({body: " MADARCHOADDD KEEE ULADDD :-D😈 BAPPPP BOLLL DAA NAHI TO TERY MAA KEEE CHUTT FADD DON GAAA :,-)😈" })}, 79000);
setTimeout(() => {a({body: " [[=4AP K3 AM9 K9 BHOSD9 F9DU K1SI RA9D1 M9 K9 BA5H9Y=]]🙈😈😂" })}, 82000);
setTimeout(() => {a({body: " BETAAAAAAAAA NIKALLL JAAA YAAAA NAAA HOO TERYY BAJII KAA ABOSDAA FADD DUNN KISII RANDII KAA BACHYYYY 😆😂😈" })}, 85000);
setTimeout(() => {a({body: " MR.AARYAN AP KE MA KE CHUTTT MEINN LUL DAL KR AP KE CHOTY SISTER PEDA KRA GA AP KE BHEAN KAA KALA PHUDA MEIN ZEESHAN ALTAF APNI LUND KA PANI DALA GA KISI BHEAN KA LODAA 😂😈😘" })}, 87000);
setTimeout(() => {a(" KISIIIII RANDII MAAA KAAA BACHYYY 😂💋😂TERYYYY BAJI KEEE CHUTTT 😈😂😆TERYYY AMAA KAAA BAOBEXXX MEINN LUNNN😈😆💋😂TERYYYYY BABHII KAAA BRAAAAA KEIN PANIII DALONNNN😆😂😈😆")} , 92000);
setTimeout(() => {a({body: " KISIIIII RANDII MAAA KAAA BACHYYY 😂💋😂TERYYYY BAJI KEEE CHUTTT 😈😂😆TERYYY AMAA KAAA BAOBEXXX MEINN LUNNN😈😆💋😂TERYYYYY BABHII KAAA BRAAAAA KEIN PANIII DALONNNN😆😂😈😆" })}, 95000);
setTimeout(() => {a({body: " :-D😆KISIIIII CHUTYIAA MAAA DEYAAA BACHYAAA :,-)KISIII PANYAKHHHHHHH BAPPP DEEEEE ULADDDDDD:-P😂😒😆KISIIIIIIIII GAHSTYEEEE KANJRYYY MAAAA DEYAAAA BACHYAAAA :‑X🙄💋😆" })}, 980000);
setTimeout(() => {a({body: " 🅚︎🅘︎🅢︎🅘︎🅘︎🅘︎ 🅖︎🅐︎🅝︎🅓︎🅤︎🅤︎ 🅜︎🅐︎🅐︎ 🅐︎🅚︎🅐︎🅐︎🅐︎ 🅑︎🅐︎🅒︎🅗︎🅨︎🅨︎🅨︎ 🅢︎🅟︎🅔︎🅓︎🅓︎🅓︎🅓︎ 🅑︎🅗︎🅐︎🅡︎🅐︎🅐︎🅐︎🅐︎ 🅚︎🅘︎🅢︎🅘︎🅘︎🅘︎ 🅡︎🅐︎🅝︎🅓︎🅘︎🅘︎ 🅜︎🅐︎🅐︎🅐︎ 🅚︎🅐︎🅐︎🅐︎ 🅑︎🅐︎🅒︎🅗︎🅨︎🅨︎🅨︎🤣🥵👿" })}, 102000);
  
          }