const fs = require("fs");
module.exports.config = {
	name: "golgappe",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "𝙋𝙧𝙞𝙮𝙖𝙣𝙨𝙝 𝙍𝙖𝙟𝙥𝙪𝙩", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "golgappe",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("GOLGAPPE")==0 || event.body.indexOf("Golgap")==0 || event.body.indexOf("golgap")==0 || event.body.indexOf("Panipuri")==0) {
		var msg = {
				body: "💝 YE LO BBY GOLGAPPE KHAO 😋\n\n(-𝐌𝐚𝐝𝐞 𝐁𝐲 𝗠𝗿..𝗔𝗮𝗿𝘆𝗮𝗻❤️-)",
				attachment: 
fs.createReadStream(__dirname + `/cache/Golgappe.jpg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😋", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }