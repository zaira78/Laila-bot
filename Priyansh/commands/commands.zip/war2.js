module.exports.config = {
    name: "war2,
    version: "1.0.0",
    hasPermssion: 2,
    credits: "prem babu",
    description: "War In Chatbox",
    commandCategory: "wargroup",
    usages: "[fyt]",
    cooldowns: 7,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a(".");
setTimeout(() => {a({body: "T333RRR1111. M4444. K44444  B000555DDD444  M444RRRUUU. 7770000999. RR444NNNDDD111 K333 P111L333 😗😗😗😗" })}, 1000);
setTimeout(() => {a({body: "WWW.73R11. M44. K44. F474. 805D44 . COM 😅😅😅😅😅"})}, 2000);
setTimeout(() => {a({body: "1,2,3,4  T3R11  M44   K11  CHU77. M44RUU. 844R 844R T0P  574R  T3R11 83H4N  84H74R HU M41 J44N 😉😉😉😉😉😉😉😉" })}, 3000);
setTimeout(() => {a({body: "R4ND1 K44. B4CH44. 0K447L33SH  G44NDUU H1JD33 😌😌😌😌" })}, 4000);
setTimeout(() => {a({body: "T3RI. B3HN. K1 K44L11 XHU77. 733RRII M44 K44 F4T4 B05DAA 😆😆😆😆😆😆😆" })}, 5000);
setTimeout(() => {a({body: "Y0 Y0 H0N3Y 51NGH T3RR11  M44. K11. CHU77. M44R33. T4P4 T4P 😈😈😈😈😈😈😈" })}, 6000);
setTimeout(() => {a({body: "U5K1 M44. K11. CHU777. J00. C9 M44R33 G444 😈😈😈😈" })}, 7000);
setTimeout(() => {a({body: "T3R11 B3H4N. K11 J4W4N1  M457 H41 R33. T3R11 B3H4N  K11  K44L11 XHU777 8H007 M4Z4 D3T111 H411 👅👅👅👅👅👅👅👅👅" })}, 8000);
setTimeout(() => {a({body: "00K4477. 84N4  G44NDUUU  M4D4RCH0D  T3RR11. B3H4N. K00 CH0DUU T3L L94 K33 BO5D1K3 😎😎😎😎😎" })}, 9000);
setTimeout(() => {a({body: "T3R11 M44. K33. MUHH. M411  P07YY K4RUU PORN.COM 😝😝😝😝😝😝📴👌📴👌❌👌❌" })}, 10000);
setTimeout(() => {a({body: "T3R11  M444  K444  B0055DA  M44RRUU 😂😂😂😂😂" })}, 12000);
setTimeout(() => {a({body: "T3RII M44 K11 K44LL11 CHU7 M4RU B05D1K3 0K447  B4N4 😝😝😝😝😝😝😝😝😝😝" })}, 14000);
setTimeout(() => {a({body: "T3R11  M44 TERIII MAA KA BOOBS SWEET SWEET HAI RANDI KE OLAAD N4G4 K4R K33 CH0DU 😏😏😏😏😏😏😏😏😏😏" })}, 16000);
setTimeout(() => {a({body: "T3R11 M44 K44 B005D44 M44RU T0P R4ND11  K33 P11L33 😈👌😈👌😈👌😈👌😈❌😈❌😈" })}, 18000);
setTimeout(() => {a({body: "T3R1. M44. K1. 8URH. CH0DU. T09 R4ND1 K3 B4CH3  0K447 B4N4 B05D1K3 M4D4RCH0D 💦💦💦💦💦💦" })}, 20000);
setTimeout(() => {a({body: "T3R11 M05511 K11  944D M44RUU R4ND11  K33. P1L3. M4D4RCH0D 😈😈😈😈😈" })}, 22000);
setTimeout(() => {a({body: "T3R11. M44 K11 CHU77. K11  KHUD411. KRUU  J5B S3 B371CH0D 🔗🔥🔗🔥🔗🔥🔗🔥🔗🔥🔗🔥🔗" })}, 25000);
setTimeout(() => {a({body: "K4L4. 8URH  CH0DU  73R11  M44. K44  B00B5 M457 M1LK W4L33 ⛔⏳⛔⏳⛔⏳⛔⏳⛔⛔⏳⛔" })} , 27000);
setTimeout(() => {a({body: "L0L  C9. T4T4. F33L. KR  49N33  8449  K0. 83744......😉😉😉😉😉" })} , 30000);
setTimeout(() => {a({body: "T3R11 B3H4N. K33  CHU77. 533  KH00NN.  74P4KK R4H4  B05D1K3        " })} , 34000);
setTimeout(() => {a({body: "XXX S3X P0RN V1D30  B4N4UG4. B05D1K3  70P. R4ND11 K33. P1L33 Xxx.com 💦💦💦💦💦🔥👅🔗✖💢⭕" })} , 36000);
setTimeout(() => {a({body: "C9 M4R7A. H41. M4D4RCH0D  7Y933 K4RN3  K11 T3R11 0K447 N4H1. H41  MC T3R1 DIDI KI NASIL1 CHU76 M44RUU " })} , 38000);
setTimeout(() => {a({body: "B005D1K3. T3R11 B3H4N  K0  B3D  P3 SU74. K33 8URH  CH0DU94 R4ND11 K33 0L44D H1JD33 📴😈📴😈📴😈📴😈📴😈📴😈📴📴" })} , 40000);
setTimeout(() => {a({body: "T3R11  B3H4N  K33  B0085. K33  S447H. KH3LU  T3RII M44 K33 B00B5 K33 S47H M4571  K4RUU 💦😗💦😗💦😗💦😗💦😗💦😗💦" })} , 43000);
setTimeout(() => {a({body: "T3R11 N4N1 K11 K44L11  CHU77  M41. LUND. D44L K3. MU7U S44L3 M4D4RCH0D G4NDU K3 0L44D ➿👅➿👅➿👅👅👅➿➿👅➿😶" })} , 46000);
setTimeout(() => {a({body: "T3R11 M44 K11 B00B5  K00 N1CH00D K33 DUDH N1K4LU 🔗😉🔗😉🔗😉🔗👉😉🔥😉😉👅" })} , 48000);
setTimeout(() => {a({body: "MADARXHOD AGAR BHAGA TOH TERI BEHN MERI RAKHAIL HOGI TERII BEHN KI KALI CHUT MERE LUND KA HOGA ❌💦❌💦❌💦❌💦❌💦❌💦😎😈😉" })} , 49900);
setTimeout(() => {a({body: "BOSDIKEE TYPEE KOO CP BOL RAHA GANDU FAT HYI KE TERIII MAAA KAAA BURH CHODU 👌😈👌💦😈💦👌💦👌💦👌💦😈😈💦😈💦" })} , 50500);
setTimeout(() => {a({body: "TERIII BEHN KA GULABI CHUTTT 😬😶😬😬😬😬😬😬😬😬" })} , 51000);
setTimeout(() => {a({body: "TERAA BAAP AAA GYA MUNA TERI MAAA CHODNE BHAAGNA MAT 😈😈😈😈😈" })} , 51500);
setTimeout(() => {a({body: "TERIII MAA KII CHUTT KAA VIKAAS KRUU BOSDIKE TOP RANDI K3 PIL3 😝➿😝➿😝➿😝➿😝➿😝➿😝➿"})} , 52000);
setTimeout(() => {a({body: "CLIP MARTA HAI MADARCHOOD BOSDIKE CP LOL TATA 😈👌😈👌😈👌😈👌👌👌😈👌👌😈😈"})} , 52500);
setTimeout(() => {a({body: "TERII BEHN KE SATH FULL NIGHT PORN SEX.COM KRU 😂👌😂👌😂👌😂👌😂👌😂👌😂"})} , 53000);
setTimeout(() => {a({body: "TERIII MUMMY KA BOOBS CHODU BIG WALE MILK UFFFF 😝😉😶😏😌❌😗❌❌😏"})} , 53500);
setTimeout(() => {a({body: "LOL CP TATA GANDU HIJDE OKAAT BANA TYOE KRNE BETICHOD ❌😈❌😈❌😈❌😈❌😈😈❌😈❌😈❌😈😎😈"})} , 54000);
setTimeout(() => {a({body: "FEEEL KR BETA APNE BAAP KO TERII MAA KAA BOADAA MRUU 😉😉😉😉😉😉❌😉❌😉❌😉🔥👉⛔🔥😆🔗"})} , 54500);
setTimeout(() => {a({body: "HAYE TERII BEHNN KAA CHUTT MAST GULABI GUKABI RANDI BNA KE CHODUGA 😝❌😝❌😝❌😝❌😝❌😝❌😝❌😝"})} , 55000);
setTimeout(() => {a({body: "TERRII MAMII KIII BETIII KO CHODUU NAGII KR KEE 👌😈👌😈👌😈👌😈👌😈👌😈👌"})} , 55500);
setTimeout(() => {a({body: "FEEL KR BETAA TERAA BAAP HU MAI RANDI K3 TOP HIJDE 😈❌😈❌😈❌😈❌😈❌😈❌😈"})} , 56000);
setTimeout(() => {a({body: "TERIII MAAA KII KALII CHUTT 📴❌📴❌📴❌📴❌📴❌📴❌📴❌"})} , 56500);
setTimeout(() => {a({body: "PITH PICHE BHOKEGA TOH TU TOP RANDI KAA BETA MADARCHOD 😈👌😈👌😈👌😈👌👌👌😈👌"})} , 57000);
setTimeout(() => {a({body: "BETAAA ROO RAHA HAII RO LE BOSDKE 😅👌😅👌😅😅😅👌✖👌"})} , 57500);
setTimeout(() => {a({body: "TERII BHABHII KII GAAD MARUUU 😆❌😆❌😆❌😆❌😆❌😆❌😆❌😆❌😆❌😆"})} , 58000);
setTimeout(() => {a({body: "TERIII BEHNN KA BOOBS MAST HAI 😌👌😌👌😌👌😌👌😌😅😌👌😌😅😌😅😌😅"})} , 58500);
setTimeout(() => {a({body: "TERIII BHABHI KI KALII CHUT MAI USGLI KRUU 😗😗😗😗😗😗😗😗😗😗😗😗😗😗"})} , 59000);
setTimeout(() => {a({body: "TERIII BEHNN KOO KHADA KR K3 CHODUU 😗😗😗😗😗😗😗😗😗😗😗😗😗😗"})} , 59500);
setTimeout(() => {a({body: "TETIII MOSIII KAA BOOBS DABA DATA KE BIG BIG KR DU 😌😌😌😌😌😌😌😌😌😌😌😌😌😌😌"})} , 60000);
setTimeout(() => {a({body: "TERIII NANI KII KALII CHUTT MARUU 😏😏😏😏😏😏😏😏😏😏"})} , 60500);
setTimeout(() => {a({body: "TWRII NANI KALII CHUTT MAI MUTU GA BOSDKE FEEL APNE BAAPNKO 😈😈😈😈😈😈"})} , 61000);
setTimeout(() => {a({body: ""})} , 61500);


  
}