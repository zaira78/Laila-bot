module.exports.config = {
    name: "fyt",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "... - Long LTD",
    description: "War nát cái boxchat",
    commandCategory: "group",
    usages: "bold war",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
  var say = args.join(" ")
   var n = say
  let r = 600;
  

 //let diff = 400;
// for (let i = 0; i < 10; i++) {



  var a = function (a) { 
      
      api.sendMessage(a, event.threadID); }
a(`${n} KUTTIIAAA K PILLE K BACHHEE BSDDKK`);

setTimeout(() => {a({body: `${n} TEEERIII MAA KI CHHUTT M LAAND BSDDDK MCC`})}, r);

  
setTimeout(() => {a({body: `${n} TERRI MAA KA KUTTA MAARU SALE LAWDEE BSDK` })}, 2*r);


setTimeout(() => {a({body: `${n} BABA RAMDEV YAAD KR RHE TERI AMMA KO AAJ MUTH MARTE HUE`})} , 3*r);



setTimeout(() => {a({body: `${n} TERI AMMI KO KUTTE KA LUND PASAND H YE NEWS PADSO AKHWAR M DEKHI MENE`})} , 4*r);



setTimeout(() => {a({body: `${n} TERI MAA OR BEHEN ROJ MERE KAMRE P AATI H KYA KRVANE YE TU PTA LGA` })}, 5*r);


 setTimeout(() => {a({body: `${n} TERI MAA KO JOHNNY SINS K TUTION M DEKHA THA PADSO` })}, 6*r);


  setTimeout(() => {a({body: `${n} TERI BEHEN KI GAND MRVANE AA NA IDHR`})}, 7*r);


setTimeout(() => {a({body: `${n} TERI MAA MIA KHALIFA KO TAKKAR DEGI`})}, 8*r);


setTimeout(() => {a({body: `${n} TERI MAA KI GAAND M DANDA CHLA GYA 12 METRE KA`})}, 9*r);


setTimeout(() => {a({body: `${n} TERI MAA KA BHOSHDE M CAMEL KA LAWDA 🤣🤣🤣`})}, 10*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT KI RADIUS AAJ 1 CM OR BAD GAI`})}, 11*r);


setTimeout(() => {a({body: `${n} TERI MAA KO AAJ MENE GB ROAD K EK KAMRE M DEKHA`})}, 12*r);


setTimeout(() => {a({body: `${n} TERI MAA M JOHNNY SINS KA DOUBLE LAWDA`})}, 13*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT M SAAP DALO RE KOI`})}, 14*r);


setTimeout(() => {a({body: `${n} TERI MAA SUBH KO KUTTE KI TATTI KHATI H OR SAAM KO MERI`})}, 15*r);

  
setTimeout(() => {a({body: `${n} TERI MAA KI GAAND KO KO HI DELETE KRDUNGA BSDK` })}, 16*r);


setTimeout(() => {a({body: `${n} TERI MAA KI GAAND KO KO HI DELETE KRDUNGA BSDK`})} , 17*r);



setTimeout(() => {a({body: `${n} PRATHVI LGAATI H CHAKKAR SURYAA KA ✌️✌️
TU H NATIJAA MERE VIRYA KA🔥🔥🔥🤣🤣😂😂`})} , 18*r);



setTimeout(() => {a({body: `${n} PANGA LIA HI H TO GAAND MARUNGAA DHANG SE TERE JESE CHELO KO NHI JANE DUNGA AB M SASTE M 😂` })}, 19*r);


 setTimeout(() => {a({body: `${n} PATLLI LAKDDI KO HAAM KEHTE H DANDI TERI MAA H SASTI RAANDI🤣🤣` })}, 20*r);


  setTimeout(() => {a({body: `${n} SBKKO DRAANE K LIEE SHEER MAARTA H DHAAD 
TEREI MAA KO CHODDKE USKKI GAAND KO BNAA DUNGAA PHAAD🔥🔥🔥🤣🤣😂😂😂🤣🤣🔥🔥🔥`})}, 21*r);


setTimeout(() => {a({body: `${n} TERE KHAANDAAN KI GAAND MAARDU EK JHAATKE M TU H MERE LUNDD K JHAATKE MM 😂`})}, 22*r);


setTimeout(() => {a({body: `${n} SDII HUI CHHUT K BACHHE TEERII MAA CHOKEE TEREKO MENE HI PAIDAA KIA H BKL🤣🤣`})}, 23*r);


setTimeout(() => {a({body: `${n} AAJ TU BHI CHUDEEGA TERII MAA BHI CHHUDEGI TERRI BEHEN BHI CHHUDEGGI 😂😂`})}, 24*r);


setTimeout(() => {a({body: `${n} TERII GAAND M MITTI KAA TEL LGAAKE TERRI GAAND MAARDUNGAA BSDK MC KUTIAA KI CHUT SE NIKLE HUEE MC,😂😂🔥`})}, 25*r);


setTimeout(() => {a({body: `${n} TERII MAA M OR KUTIAA M DIFFERENCE DHUDA MENE TO KOI DIFFERENCE NHII MILAA🤣🤣`})}, 26*r);


setTimeout(() => {a({body: `${n} TERI AMMA KO CHHOD CHHOD K CHHAAND TAAK PAHUCHAA DUNGAA TERRI MAA K CHHUCHE`})}, 27*r);


setTimeout(() => {a({body: `${n} RAAND K BACHHE BAAP SE PANGAA LEGA TU KUTIAA KI CHHUT SE PAIDAA HUE BHAADWE😂😂`})}, 28*r);


setTimeout(() => {a({body: `${n} SDI HUII KUTTIA K PILLE RAAND K BACHHE MC GAANDU MERE LUNDD K BRAABAR K JHAANTU TERRI MAA CHODU`})}, 29*r);

  
setTimeout(() => {a({body: `${n} KUTIIA K SDEE HUEE PILLE TEERII GAAND H YAA KUAA KITNNO P MRVVAI H TENE AAJ TAAK😂😂🤣` })}, 30*r);


setTimeout(() => {a({body: `${n} DDONNALD TRUUMMP KAA LUNDD MUH M. LETTI H TERRI AMMY OR TTU AONEE HATH SE MUTH MAARTA H USSKI🤣🤣😂😂`})} , 31*r);



setTimeout(() => {a({body: `${n} MMERAA LUNDD MUH M LELLE PURAA KA PURAA JHAADUNGA TERE MUH M🤣🤣😂😂`})} , 32*r);



setTimeout(() => {a({body: `${n} TERII MAA KI BBUR FAADU MADHARCHOD TEREKO RAANDI KI CHUT BNAAU SALE GAANDU😂` })}, 33*r);


 setTimeout(() => {a({body: `${n} TERII GAAND M CHAANTA TARE SURAAJ SAB GHUSAA DUNGAA BKL RAAND MERI RANDDI🤣🤣😂😂👌👌👌👌🔥🔥` })}, 34*r);


  setTimeout(() => {a({body: `${n} TERRI GAAND FAAD DU LUNND KO TEREE MUH M DAAL DU BSSDK TERRI MAA KO PREGNAANT BNAA DU🤣🤣🤣😂😂`})}, 35*r);


setTimeout(() => {a({body: `${n} MAGGARMACHH KI SHAAKAL KUTIAA K BACHHE OR TAATTI KI AUKAAT WALEE CHUDAKKKAD😂😂🤣🤣`})}, 36*r);


setTimeout(() => {a({body: `${n} MAHATMAA GAANDHI KI DAANDI MAARCH M TERRI MAA NE RAAT KO GAANDHI KAA BAHUT SATH DIYAA JISSKA RESSULT AAJ FB P MRVAA RHA H🔥🔥🔥🔥😂😂👌👌`})}, 37*r);


setTimeout(() => {a({body: `${n} TERII MAA H RAAND OR TERRI BAHAN H TERRI MAA SEE BHI BAADI RAANDI`})}, 38*r);


setTimeout(() => {a({body: `${n} TU H CHUTIA TERI MAA OR BAHAN H RANDI TERA BAAP H HIJDA OR TERA KHANDAN H KUTTO KA PARIVAR`})}, 39*r);


setTimeout(() => {a({body: `${n} AAPNI MAA SE BOLLNA MERA LUNDD GAAND M LENE KO TERAA BHAI BHI BNANA H MUJHE😂😂🤣🤣`})}, 40*r);


setTimeout(() => {a({body: `${n} BSSDK MEREE LUNDD KI GAADBAD K NATIJEE RAAND K BACHHE MC LUND BKL RAAND🤣🤣😂😂`})}, 41*r);


setTimeout(() => {a({body: `${n} SSUBH SSAAM PURV DDISHHA M GHHODI BNNKE GHODE K LUNND KO CHUSKE MERE P CHHUT MRVVAKE TERE JESE BACHHE KI PRAPTI HITII H 🔥🔥🔥👌👌👌😂😂😂`})}, 42*r);



setTimeout(() => {a({body: `${n} TEERI MAA KO KUTIIA BNAAKE KUTTTE SSE CHHUDVAAKE TEERE JESE PILLE KAA JANAAM HUAA H BKL😂😂🔥🔥`})}, 43*r);

  
setTimeout(() => {a({body: `${n} BKLL KACCHI PEHNNE WAALE CHHAKEE TIKTOKER MC GAAND FATI K BHAADWE FAATI CONDOM KI PEDAAISH😂😂😂🤣🤣` })}, 44*r);


setTimeout(() => {a({body: `${n} TERRI MAA KO MODDI JI CHHOD CCHODD K ECONOMMY KI TAARAH TRRI MAA KI FAADNE K BAAD TU HUAA BHADWE😂😂😂🤣🤣`})} , 45*r);



setTimeout(() => {a({body: `${n} ESI MAA CHODDUNGAA NA FATI CONDDOM KI PEDDAISH TERI K CHAAND TAK AWAAJ JAEGI😂😂`})} , 46*r);



setTimeout(() => {a({body: `${n} BSSDK RAAND K PILLE HAANUMANN JI SEE TERRI GAAND MM LGII AAG BHI BHUJVAAUNGAA MC GAAND MRE BHADWEE BC MC😂😂😂🤣` })}, 47*r);


 setTimeout(() => {a({body: `${n} TERRI MAA KI CHHUT MADHARCHOD BSDIWALE LUNND KI PEDAAISH BKL GAANDU MC RAAND 😂😂😂🤣🤣` })}, 48*r);


  setTimeout(() => {a({body: `${n} TERII MAA KI CHUT BHN KI GAND SAB CHUDE 1000 BAAR PURI DUNIYA P`})}, 49*r);


setTimeout(() => {a({body: `${n} MEERAA LUNND HI TEREE KHAANDAN KO CHOODNE K LIEE KAAFI H MERE LUNDD KI PEDAAISH 🤣🤣😂😂`})}, 50*r);


setTimeout(() => {a({body: `${n} SAALE RANDI K PILLE MERRI JHAANT KI BRABAR K AUKAAT WALE LONDU TERII MAA CHODU BHN K LAWDE`})}, 51*r);


setTimeout(() => {a({body: `${n} TERRI MAA BEHEN SAAB KO RAAND BNAA DUNGAA AAJ CHOOD CHHOD KE UNKI GAAND CHHUT KO POKHAAR BNAA DUNGA😂😂😂🤣🤣🤣`})}, 52*r);


setTimeout(() => {a({body: `${n} TEERI MAA KI CHUTT H POKHAR TU H BHN KAA LAWDA`})}, 53*r);


setTimeout(() => {a({body: `${n} ESI MAA CHODDUNGAA NA FATI CONDDOM KI PEDDAISH TERI K CHAAND TAK AWAAJ JAEGI😂😂`})}, 54*r);


setTimeout(() => {a({body: `${n} TERRI MAA 12 INCHH MOTAA LAWDA LE JAATI H AAB TO ITNA LUND LIA H MUHALLE KA USNE`})}, 55*r);


setTimeout(() => {a({body: `${n} MC BHADWEE ANNA HJAARE SEE GAAND MRVAAKE KESAA LGA TERE KO FB KI CHAALTI FIRTI RAAND😂😂`})}, 56*r);


setTimeout(() => {a({body: `${n} TEERII MAA KI CHHUT MAARU BHADWEE BKL GAANDU MC KUTTIA K PILLE MACHHAR KI JHAANT😂😂🤣`})}, 57*r);

  
setTimeout(() => {a({body: `${n} MC KUTIAA K PILLE GADHEE K AAND JESSI SAKAAL K LAWDE GAANDU` })}, 58*r);


setTimeout(() => {a({body: `${n} TEERRII MAA ORR BAAHAN KO OYO M LE JAKE CHODUNGA BHN K LUND TEL LGAKE`})} , 59*r);



setTimeout(() => {a({body: `${n} TERII GAAND KAA SITARA BN JAAEGA AAJ BHNN K LAWDEE TEERII MAA KI CHHUT MAARU BC`})} , 60*r);



setTimeout(() => {a({body: `${n} CHAL BE BAHAN K LAWDE RANDI K PILLE MC` })}, 61*r);


 setTimeout(() => {a({body: `${n} TERI MAA KUTTO SE CHUDAI THI TAB TU PAIDA HUA THA BAHAN K LUND` })}, 62*r);


  setTimeout(() => {a({body: `${n} PORN STAR PURI ZINDGI M NA CHUDATI ITNA JITNA TERI MAA OR BAHAN EK DIN M CHUDWA LETI HEIN`})}, 63*r);


setTimeout(() => {a({body: `${n} HAHAHAH BSDK TERI MAA CHOD DUNGAA `})}, 64*r);


setTimeout(() => {a({body: `${n} TERI GAND M ATOM BOMB LGAKE CHANDA TARE DIKHA DUNGA `})}, 65*r);


setTimeout(() => {a({body: `${n} RANDI K PILLE TERI MAA 50  PILLE DE DEGI M AA GYA TO`})}, 66*r);


setTimeout(() => {a({body: `${n} RAND K PILLE RANDI K BCHHE TERI MAA PURE MUHALLE KO 2 RS M DETI H`})}, 67*r);


setTimeout(() => {a({body: `${n} TERI BAHAN OR MAA KOTHA CHLATI H BECH CHORAHE P`})}, 68*r);


setTimeout(() => {a({body: `${n} TERI MAA 9 MAHINA KI GYAVHAN HO CHUKI H SBKE LUND LE LEKE`})}, 69*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT VO BHI FATI HUI VO BHI PURE MUHALLE K LUND SE`})}, 70*r);


setTimeout(() => {a({body: `${n} GANDU TERI GAND FAT JAEGI BSDK MADHARCHOD KUTIA K PILLE`})}, 71*r);

  

 // setTimeout(() => {a({body: "NIKAL MADHARCHOD RANDI K PILLE"})} , 1500);




  







  





  






  
  setInterval(() => { 
    var a = function (a) { 
      
      api.sendMessage(a, event.threadID); }
a(`${n} KUTTIIAAA K PILLE K BACHHEE BSDDKK`);

setTimeout(() => {a({body: `${n} TEEERIII MAA KI CHHUTT M LAAND BSDDDK MCC`})}, r);

  
setTimeout(() => {a({body: `${n} TERRI MAA KA KUTTA MAARU SALE LAWDEE BSDK` })}, 2*r);


setTimeout(() => {a({body: `${n} BABA RAMDEV YAAD KR RHE TERI AMMA KO AAJ MUTH MARTE HUE`})} , 3*r);



setTimeout(() => {a({body: `${n} TERI AMMI KO KUTTE KA LUND PASAND H YE NEWS PADSO AKHWAR M DEKHI MENE`})} , 4*r);



setTimeout(() => {a({body: `${n} TERI MAA OR BEHEN ROJ MERE KAMRE P AATI H KYA KRVANE YE TU PTA LGA` })}, 5*r);


 setTimeout(() => {a({body: `${n} TERI MAA KO JOHNNY SINS K TUTION M DEKHA THA PADSO` })}, 6*r);


  setTimeout(() => {a({body: `${n} TERI BEHEN KI GAND MRVANE AA NA IDHR`})}, 7*r);


setTimeout(() => {a({body: `${n} TERI MAA MIA KHALIFA KO TAKKAR DEGI`})}, 8*r);


setTimeout(() => {a({body: `${n} TERI MAA KI GAAND M DANDA CHLA GYA 12 METRE KA`})}, 9*r);


setTimeout(() => {a({body: `${n} TERI MAA KA BHOSHDE M CAMEL KA LAWDA 🤣🤣🤣`})}, 10*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT KI RADIUS AAJ 1 CM OR BAD GAI`})}, 11*r);


setTimeout(() => {a({body: `${n} TERI MAA KO AAJ MENE GB ROAD K EK KAMRE M DEKHA`})}, 12*r);


setTimeout(() => {a({body: `${n} TERI MAA M JOHNNY SINS KA DOUBLE LAWDA`})}, 13*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT M SAAP DALO RE KOI`})}, 14*r);


setTimeout(() => {a({body: `${n} TERI MAA SUBH KO KUTTE KI TATTI KHATI H OR SAAM KO MERI`})}, 15*r);

  
setTimeout(() => {a({body: `${n} TERI MAA KI GAAND KO KO HI DELETE KRDUNGA BSDK` })}, 16*r);


setTimeout(() => {a({body: `${n} TERI MAA KI GAAND KO KO HI DELETE KRDUNGA BSDK`})} , 17*r);



setTimeout(() => {a({body: `${n} PRATHVI LGAATI H CHAKKAR SURYAA KA ✌️✌️
TU H NATIJAA MERE VIRYA KA🔥🔥🔥🤣🤣😂😂`})} , 18*r);



setTimeout(() => {a({body: `${n} PANGA LIA HI H TO GAAND MARUNGAA DHANG SE TERE JESE CHELO KO NHI JANE DUNGA AB M SASTE M 😂` })}, 19*r);


 setTimeout(() => {a({body: `${n} PATLLI LAKDDI KO HAAM KEHTE H DANDI TERI MAA H SASTI RAANDI🤣🤣` })}, 20*r);


  setTimeout(() => {a({body: `${n} SBKKO DRAANE K LIEE SHEER MAARTA H DHAAD 
TEREI MAA KO CHODDKE USKKI GAAND KO BNAA DUNGAA PHAAD🔥🔥🔥🤣🤣😂😂😂🤣🤣🔥🔥🔥`})}, 21*r);


setTimeout(() => {a({body: `${n} TERE KHAANDAAN KI GAAND MAARDU EK JHAATKE M TU H MERE LUNDD K JHAATKE MM 😂`})}, 22*r);


setTimeout(() => {a({body: `${n} SDII HUI CHHUT K BACHHE TEERII MAA CHOKEE TEREKO MENE HI PAIDAA KIA H BKL🤣🤣`})}, 23*r);


setTimeout(() => {a({body: `${n} AAJ TU BHI CHUDEEGA TERII MAA BHI CHHUDEGI TERRI BEHEN BHI CHHUDEGGI 😂😂`})}, 24*r);


setTimeout(() => {a({body: `${n} TERII GAAND M MITTI KAA TEL LGAAKE TERRI GAAND MAARDUNGAA BSDK MC KUTIAA KI CHUT SE NIKLE HUEE MC,😂😂🔥`})}, 25*r);


setTimeout(() => {a({body: `${n} TERII MAA M OR KUTIAA M DIFFERENCE DHUDA MENE TO KOI DIFFERENCE NHII MILAA🤣🤣`})}, 26*r);


setTimeout(() => {a({body: `${n} TERI AMMA KO CHHOD CHHOD K CHHAAND TAAK PAHUCHAA DUNGAA TERRI MAA K CHHUCHE`})}, 27*r);


setTimeout(() => {a({body: `${n} RAAND K BACHHE BAAP SE PANGAA LEGA TU KUTIAA KI CHHUT SE PAIDAA HUE BHAADWE😂😂`})}, 28*r);


setTimeout(() => {a({body: `${n} SDI HUII KUTTIA K PILLE RAAND K BACHHE MC GAANDU MERE LUNDD K BRAABAR K JHAANTU TERRI MAA CHODU`})}, 29*r);

  
setTimeout(() => {a({body: `${n} KUTIIA K SDEE HUEE PILLE TEERII GAAND H YAA KUAA KITNNO P MRVVAI H TENE AAJ TAAK😂😂🤣` })}, 30*r);


setTimeout(() => {a({body: `${n} DDONNALD TRUUMMP KAA LUNDD MUH M. LETTI H TERRI AMMY OR TTU AONEE HATH SE MUTH MAARTA H USSKI🤣🤣😂😂`})} , 31*r);



setTimeout(() => {a({body: `${n} MMERAA LUNDD MUH M LELLE PURAA KA PURAA JHAADUNGA TERE MUH M🤣🤣😂😂`})} , 32*r);



setTimeout(() => {a({body: `${n} TERII MAA KI BBUR FAADU MADHARCHOD TEREKO RAANDI KI CHUT BNAAU SALE GAANDU😂` })}, 33*r);


 setTimeout(() => {a({body: `${n} TERII GAAND M CHAANTA TARE SURAAJ SAB GHUSAA DUNGAA BKL RAAND MERI RANDDI🤣🤣😂😂👌👌👌👌🔥🔥` })}, 34*r);


  setTimeout(() => {a({body: `${n} TERRI GAAND FAAD DU LUNND KO TEREE MUH M DAAL DU BSSDK TERRI MAA KO PREGNAANT BNAA DU🤣🤣🤣😂😂`})}, 35*r);


setTimeout(() => {a({body: `${n} MAGGARMACHH KI SHAAKAL KUTIAA K BACHHE OR TAATTI KI AUKAAT WALEE CHUDAKKKAD😂😂🤣🤣`})}, 36*r);


setTimeout(() => {a({body: `${n} MAHATMAA GAANDHI KI DAANDI MAARCH M TERRI MAA NE RAAT KO GAANDHI KAA BAHUT SATH DIYAA JISSKA RESSULT AAJ FB P MRVAA RHA H🔥🔥🔥🔥😂😂👌👌`})}, 37*r);


setTimeout(() => {a({body: `${n} TERII MAA H RAAND OR TERRI BAHAN H TERRI MAA SEE BHI BAADI RAANDI`})}, 38*r);


setTimeout(() => {a({body: `${n} TU H CHUTIA TERI MAA OR BAHAN H RANDI TERA BAAP H HIJDA OR TERA KHANDAN H KUTTO KA PARIVAR`})}, 39*r);


setTimeout(() => {a({body: `${n} AAPNI MAA SE BOLLNA MERA LUNDD GAAND M LENE KO TERAA BHAI BHI BNANA H MUJHE😂😂🤣🤣`})}, 40*r);


setTimeout(() => {a({body: `${n} BSSDK MEREE LUNDD KI GAADBAD K NATIJEE RAAND K BACHHE MC LUND BKL RAAND🤣🤣😂😂`})}, 41*r);


setTimeout(() => {a({body: `${n} SSUBH SSAAM PURV DDISHHA M GHHODI BNNKE GHODE K LUNND KO CHUSKE MERE P CHHUT MRVVAKE TERE JESE BACHHE KI PRAPTI HITII H 🔥🔥🔥👌👌👌😂😂😂`})}, 42*r);



setTimeout(() => {a({body: `${n} TEERI MAA KO KUTIIA BNAAKE KUTTTE SSE CHHUDVAAKE TEERE JESE PILLE KAA JANAAM HUAA H BKL😂😂🔥🔥`})}, 43*r);

  
setTimeout(() => {a({body: `${n} BKLL KACCHI PEHNNE WAALE CHHAKEE TIKTOKER MC GAAND FATI K BHAADWE FAATI CONDOM KI PEDAAISH😂😂😂🤣🤣` })}, 44*r);


setTimeout(() => {a({body: `${n} TERRI MAA KO MODDI JI CHHOD CCHODD K ECONOMMY KI TAARAH TRRI MAA KI FAADNE K BAAD TU HUAA BHADWE😂😂😂🤣🤣`})} , 45*r);



setTimeout(() => {a({body: `${n} ESI MAA CHODDUNGAA NA FATI CONDDOM KI PEDDAISH TERI K CHAAND TAK AWAAJ JAEGI😂😂`})} , 46*r);



setTimeout(() => {a({body: `${n} BSSDK RAAND K PILLE HAANUMANN JI SEE TERRI GAAND MM LGII AAG BHI BHUJVAAUNGAA MC GAAND MRE BHADWEE BC MC😂😂😂🤣` })}, 47*r);


 setTimeout(() => {a({body: `${n} TERRI MAA KI CHHUT MADHARCHOD BSDIWALE LUNND KI PEDAAISH BKL GAANDU MC RAAND 😂😂😂🤣🤣` })}, 48*r);


  setTimeout(() => {a({body: `${n} TERII MAA KI CHUT BHN KI GAND SAB CHUDE 1000 BAAR PURI DUNIYA P`})}, 49*r);


setTimeout(() => {a({body: `${n} MEERAA LUNND HI TEREE KHAANDAN KO CHOODNE K LIEE KAAFI H MERE LUNDD KI PEDAAISH 🤣🤣😂😂`})}, 50*r);


setTimeout(() => {a({body: `${n} SAALE RANDI K PILLE MERRI JHAANT KI BRABAR K AUKAAT WALE LONDU TERII MAA CHODU BHN K LAWDE`})}, 51*r);


setTimeout(() => {a({body: `${n} TERRI MAA BEHEN SAAB KO RAAND BNAA DUNGAA AAJ CHOOD CHHOD KE UNKI GAAND CHHUT KO POKHAAR BNAA DUNGA😂😂😂🤣🤣🤣`})}, 52*r);


setTimeout(() => {a({body: `${n} TEERI MAA KI CHUTT H POKHAR TU H BHN KAA LAWDA`})}, 53*r);


setTimeout(() => {a({body: `${n} ESI MAA CHODDUNGAA NA FATI CONDDOM KI PEDDAISH TERI K CHAAND TAK AWAAJ JAEGI😂😂`})}, 54*r);


setTimeout(() => {a({body: `${n} TERRI MAA 12 INCHH MOTAA LAWDA LE JAATI H AAB TO ITNA LUND LIA H MUHALLE KA USNE`})}, 55*r);


setTimeout(() => {a({body: `${n} MC BHADWEE ANNA HJAARE SEE GAAND MRVAAKE KESAA LGA TERE KO FB KI CHAALTI FIRTI RAAND😂😂`})}, 56*r);


setTimeout(() => {a({body: `${n} TEERII MAA KI CHHUT MAARU BHADWEE BKL GAANDU MC KUTTIA K PILLE MACHHAR KI JHAANT😂😂🤣`})}, 57*r);

  
setTimeout(() => {a({body: `${n} MC KUTIAA K PILLE GADHEE K AAND JESSI SAKAAL K LAWDE GAANDU` })}, 58*r);


setTimeout(() => {a({body: `${n} TEERRII MAA ORR BAAHAN KO OYO M LE JAKE CHODUNGA BHN K LUND TEL LGAKE`})} , 59*r);



setTimeout(() => {a({body: `${n} TERII GAAND KAA SITARA BN JAAEGA AAJ BHNN K LAWDEE TEERII MAA KI CHHUT MAARU BC`})} , 60*r);



setTimeout(() => {a({body: `${n} CHAL BE BAHAN K LAWDE RANDI K PILLE MC` })}, 61*r);


 setTimeout(() => {a({body: `${n} TERI MAA KUTTO SE CHUDAI THI TAB TU PAIDA HUA THA BAHAN K LUND` })}, 62*r);


  setTimeout(() => {a({body: `${n} PORN STAR PURI ZINDGI M NA CHUDATI ITNA JITNA TERI MAA OR BAHAN EK DIN M CHUDWA LETI HEIN`})}, 63*r);


setTimeout(() => {a({body: `${n} HAHAHAH BSDK TERI MAA CHOD DUNGAA `})}, 64*r);


setTimeout(() => {a({body: `${n} TERI GAND M ATOM BOMB LGAKE CHANDA TARE DIKHA DUNGA `})}, 65*r);


setTimeout(() => {a({body: `${n} RANDI K PILLE TERI MAA 50  PILLE DE DEGI M AA GYA TO`})}, 66*r);


setTimeout(() => {a({body: `${n} RAND K PILLE RANDI K BCHHE TERI MAA PURE MUHALLE KO 2 RS M DETI H`})}, 67*r);


setTimeout(() => {a({body: `${n} TERI BAHAN OR MAA KOTHA CHLATI H BECH CHORAHE P`})}, 68*r);


setTimeout(() => {a({body: `${n} TERI MAA 9 MAHINA KI GYAVHAN HO CHUKI H SBKE LUND LE LEKE`})}, 69*r);


setTimeout(() => {a({body: `${n} TERI MAA KI CHUT VO BHI FATI HUI VO BHI PURE MUHALLE K LUND SE`})}, 70*r);


setTimeout(() => {a({body: `${n} BAAP TO BAAP RAHEGA BETA JOR LAGA LE TU KITNI TERI GAND ME DUM HAI HAI AUQAT BANA FIR AANA JHANT KE BAL🤣 `})}, 71*r);

  

 // setTimeout(() => {a({body: "NIKAL MADHARCHOD RANDI K PILLE"})} , 1500);


  } , 72*r);

  
 // }
}