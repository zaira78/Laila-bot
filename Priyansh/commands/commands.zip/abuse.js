module.exports.config = {
    name: "abuse",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Meera Rajput",
    description: "5 বারের জন্য ক্রমাগত বন্ধুর ট্যাগ ট্যাগ করুন\nসেই ব্যক্তিকে আত্মা কলিং বলা যেতে পারে",
    commandCategory: "nsfw",
    usages: " please @mention",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
    var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("YOUR FATHER CHUZA  ENTER 💓🌞", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("THE ALONE GANG DESTROYER MR.AARYAN BABU ENTER 💓🍓");
setTimeout(() => {a({body: "TERRI AMAAA KIIIII CHUTTTTT MAARUUUUU MADARCHOD KEE BACCHEEE CHAALLL AJAA TERAA BAAAPPP READYYY HAIIII ABBBH 😈😈😈।" + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "‎AAJAAA RANNDDIIII KAA BACHAA DARRRR MAATTT CHAALLLLL COOOVERRR KAARRR BAAAPPPP BOLLLLL .." + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "‎ TERRI NANIIII KI KALIIII GANDDD MARUUUUU MADARCHOD DAARRRRRR MAATTTTTT CHINNAALLL KEE BACCHEE 😈😈😈༅༎•❤️🌸🐰" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "‎SORRY DOSTTT GALLLTIII APKIII MAAAA CHODDD DIIII MENE 😂😂😂 " + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: " CHAALLLL BETE BAAAPP KAA LOOODAA HILLAA ROOOOO MAATTTT GANNDDUU KE BACHE BAAAPP HUU TERAA 😈🤬" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "OYEEE FATE CONDOMM KEE NATIJEEE TERI AMAA KAA BHOOOXDAAA FADDUUU BHIKHARI SALEEE 🤬🤬 " + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "- SUNAA HAIII TUU TERRI AMAAAA KI CHUTTTTT BECHKKAARRR FB CHALATA HAIIII SACH HAII KYAA YEEE ?" + " " + name, mentions: arraytag})}, 17000);
setTimeout(() => {a({body: "RANNDDIIII KAA BACCHAA HAIIII TUUUU CHAMAMMAARRR KEE BACHEE ROOOO MAATTTT BHADWAA KAA BACHAAA 🤣🤣🤣" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: " SALEE KUTTEEE KI OULLAADDD TERII BUAAA CHOODDUUU BHAGA BHAGA KEE GANDUU KE BACHEE 🤬🤬" + " " + name, mentions: arraytag})},23000);
setTimeout(() => {a({body: "- TUU LADEGA BAAAPP SE KIIIREE MAKOOOREE SALEEE TERRII AMAA KAA BURRR MARUUUU GANDUU CHAMAMMARR 🙊🐥" + " " + name, mentions: arraytag})},26000);  
setTimeout(() => {a({body: "CHINNAALLL KAA BACHAA DARRR MAT RANDD KE BETEEE TERRII AMAA KI GANDD LEKE AJAA YAHAA 🤣😈" + " " + name, mentions: arraytag})},29000);
  setTimeout(() => {a({body: "-TUM MAJDURRR HOOOO 🤣🤣🤣" + " " + name, mentions: arraytag})},32000);
  setTimeout(() => {a({body: " SUNOOO DOSTT APKII AMAA KOOI GHODIII BANAA KE CHODUNGAA FULLL NIGHHTTTT NONNN 😂😂" + " " + name, mentions: arraytag})},35000);
  setTimeout(() => {a({body: "TERII AMAA KOOTHEE PEE CHUUTTTT DETIII HAIIII GANNDDUUU KEE BACCCHEEE BHNNNGHIIIII 🙊🙊" + " " + name, mentions: arraytag})},38000);
  setTimeout(() => {a({body: "-SUWARRRR KI OULAADDD KAHA GYAA BHADWEE AJAAA CHUT DE DE TERII AMAA KIII YAHAA PEE 🧐🧐" + " " + name, mentions: arraytag})},41000);
  setTimeout(() => {a({body: " APKIII BUAAA CHODUUUU GANNDDUUU KEE BACCHEE DARROOO MAT RANNDDIII KEE BACCHEE HOOOO AAAPP 🌞🌞" + " " + name, mentions: arraytag})},44000);
  setTimeout(() => {a({body: " BHENNN KEE LOOOREEE TERII AMAA CHUDD GAYI KYAA JHATUUU SALEE 😆😆" + " " + name, mentions: arraytag})},47000);
  setTimeout(() => {a({body: "VAISHYA KII OULAADDD SALEE BHADWA ROOOO MAT TERI AMAA CHOD DUNGAA WARNAA CHAPRASSIIIII SALEE 😐😐" + " " + name, mentions: arraytag})},50000);
  setTimeout(() => {a({body: "TERIII DADDIII KI BURRR MEE HATHIII KAAA LUNDDD DALUNGAA GANNDDU SALEE GAWARR KE BACHEE 😈😈" + " " + name, mentions: arraytag})},53000);
  setTimeout(() => {a({body: "✨🐰 SUNN MADARCHOD TERRII AMAA KIIII CHUTTT LENE KABB AAUUU TERE GHAARRR PEE 🤔🤭" + name, mentions: arraytag})},56000);
  setTimeout(() => {a({body: "CHINNAALLL KEE BACCHEEE TERRII AMAA CHODUNGAA BHAGA BHAGA KEE GANNDDUUU KI OULLAADDD 😆😆😆" + name, mentions: arraytag})},59000);
  setTimeout(() => {a({body: "BAAPPP SE LADEGAA BHEN KEE LOOREE PEHLE BAAAP JITNII SPEEDD TOH BANA LEE SLOWW TATEEE 🙊🙊🙊" + name, mentions: arraytag})},62000);
  setTimeout(() => {a({body: " TUUU MADARCHOD SALAA SLOWW TATA LADNEE AAYAA HAIII BAAAPPP SEE 🌞🌞🌞" + name, mentions: arraytag})},65000);
  setTimeout(() => {a({body: "SUNNN PAISE LE LE MAGARR TERII BHENN KI CHUTTT DIKHAA DE BASS EKKK BAARRR 💤💤😂" + name, mentions: arraytag})},68000);
  setTimeout(() => {a({body: " HIJRAA KA BACHAAA JHATTT KAA BAAALL HAIIII TUUUU 😹😹😹" + name, mentions: arraytag})},71000);
  setTimeout(() => {a({body: " TERIII MOSHIII KI GANDD MEE APNA LUNDD DALUNGAA BETEEE 🌞🙊🙊" + name, mentions: arraytag})},74000);
  setTimeout(() => {a({body: "T3R!! M99 D!! KUSS W!XH L9N MRUB Y9T33M D!Y9 B9CH9 M9D9R XH0D K9 B9CH3 R9ND!! K UL9D T3R! BH3N K! KUSS F9R DUNG9 M3 T3R!! M99 CHUD DUNGAW😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 3000);
setTimeout(() => {a({body: "T3R!!! BH3N NU NU L9N M9RU T3R!! T3R!!! BH3N K!! D!M9GH M3 L9ND M9RK3 US3 P9G K9R DU M9DR XH0D B9GN9 JURM H9 T3R!! M99 K!! KUS FRU😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 6000);
setTimeout(() => {a({body: "T3R!! M99 D!! J9W9N!! K9H J9UNG9 MWR9 B9CH9 TWR!!! M99 XHUD DUNG9 Y9T33M K9 B9CH3 T3R!!! R9ND!!! BH3N K!! KUS M3 M9N!! MRU T3R!! BH3N K!! CHUT 9Z9B KRU😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "T3R!!!! M99 K!! KUSS F9T G9Y9 Y9T33M G9NDU CHUD G9Y9 N9 T3R!!! M99 K! KUSS !TN9 J9LD!! T3R! M99 CHUD J9T9 H9 L9N9T!! K B9CH3 TWR! M99  K! KUSS P9R L9N9T😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "TWR!!! P9!N NU L9N M9RU T3R!! S3XY BH3N K! KUSS M3 GUS J9UNG9 M3 T3R!!! BH3N K!! S9TH S3X KRUNG9 T3R!! BH3N K0 B9CH9 H0G9 Y9T33M K UL9D😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "T3R!!! S3XY M99 K S9TH S3XY CH9T K9RK3 US3 F9C3B00K R9ND!! B9N9 DU T3R!!! BH3N K!! KUS F9R K3 US3 T0P R9ND!! G9SHT!! UR9TH B9N9 DU😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 18000);
setTimeout(() => {a({body: "T3R!!! BH3N K!! KUSS M3 L9ND T0KU L9L K9RK3 US3 P3NK DUNG9 T3R!! BH3N K0 CH9RS3 P3L9 K US3 R9ND!! CH9KL3 B9Z B9N9 DUNG9 Y9T33M K99W B9CH99 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 21000);
setTimeout(() => {a({body: "T3R!!! BH3N K!! KUSS M3 L9ND T0KU L9L K9RK3 US3 P3NK DUNG9 T3R!! BH3N K0 CH9RS3 P3L9 K US3 R9ND!! CH9KL3 B9Z B9N9 DUNG9 Y9T33M😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 24000);
setTimeout(() => {a({body: "T3R!!! N9GN!!! BH3N K!! V!D30 B9N9 DUNG9 Y0UTUB3 UPL09D KRUNG9 YTW3M M99 K B9CH3 T3R!!! M99 K!! CHUT S3 B9CH9 N!K9LL DUNG9 L!G!R! K9 B9CH9 😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 27000);
setTimeout(() => {a({body: "T3R!!! CHUT!!! BH3N K!! CHUD9!! K9RK3 M3N3 USK9 S39L TH0R D!Y9 R9ND! K9 B9CH3 T3R! BH3N K!! SH9D!! C3NC3L H0 G9Y9 T3R9 P9P9 N3 TWR! M99 XHUD D!Y9😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 30000);
setTimeout(() => {a({body: "T3R!!! M999 D!!! KUSS W!CH M3R9 L9N MRU T3R! BH3N K!! KUSS M3 L9N H33 L9N Y9T33M K9 B9CH3 T3R! M99 XHUD D!Y9 N9 M3N3 M3R9 B9CH9😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 33000);
setTimeout(() => {a({body: "T3R!!! BH3N K0 ULT9 L9TK9 K XHUDU T3R! BH3N K0 XHUD XHUD K F9R DU T3R!!! SM0XY B9J!! J9N M3R9 L9ND CH9TN3 L9G J9T9 H9 R9ND!! D!Y9 B9CH9😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 36000);
setTimeout(() => {a({body: "T3R!!! 9P!! J9N K!! CHUT S3 B9CH9 N!K9LL K9R USK9 N9M3 R9ND!! K9 B9CH9 R9K DUNG9 M3 T3R!! BH3N CHUD DUNG9 R9ND! K9 B9CH3 M9D9R CH0D F9ML!Y S3 H9 TU😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 39000);
setTimeout(() => {a({body: "T3R!!! R9ND!! 9M!! J9N CHUDN3 W9L9 T3R!! M99 K!! KUSS M3 L9ND D9LN3 W9L9 T3R9 P9P9 M3 HU T3R!!! BH3N K!! Z!ND9G!! KH9R9B M3N3 K!9 T9H Y9T33M K UL9D😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 42000);
setTimeout(() => {a({body: "T3R!!! SM0XY BH3N J0 G9R K9 L9DL9 H9 USK!! B!! KUSS F9T J9YG9  M3R9 L9N B9RD9SHT NH!! K9R P9YG9 P9TH9N M9D9R XH0D K9 B9CH9 T3R9 P9P9 H3R3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 45000);
setTimeout(() => {a({body: "TUM9RII SHC00L JT3 HU3 BH3N K0 KIDN9P KRK3 USKIII ZIND9GI KH9R9B KRU M3 W9HII HU T3RI M9W KI J9W9NI K9H LIIY9😆❤️]]\n\n" + " " + name, mentions: arraytag})}, 48000);
setTimeout(() => {a({body: "T3RI M9W KI J9W9NIII M3 L0LIX M9RU R9NDIII K9W B9CH9W TWRII SM0XY BH3N KI CHUT H9C33N K9NJR3 K3 B9CH3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 51000);
setTimeout(() => {a({body: "T3RII B3H9N K0 L3T9 K9R LAND M9R0 KISI 9D9MKH0R R9NDII K3Y B9CHY T3RI M9N NU LUN DIW9😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 54000);
setTimeout(() => {a({body: "T3RII B3H9N DII K9LI K0S M9RN KISI M0TI T3X9N DI9 B9CH9W T3RI D9DI D9 PHUD9 T0K9N R9NDII K3😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 57000);
setTimeout(() => {a({body: "T3RI B3H9N DI SUST G9ND M9 LUN D3K9R USKI G9ND URR9 D9LU KISI M0TI G9ND W9LI DI9 B9CH9 T3RI M9W D9 SHOL9😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 60000);
setTimeout(() => {a({body: "KIDS SUN T3RI M9W KI CHUT F9RU CH0MTIY9 K9 B9CH9 T3RI M9W NU L9N M9RU KISI G9SHTII D9 B9CH9😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 63000);
setTimeout(() => {a({body: "SUN9 H9 T3RI BH3N N9NG9 GUMT9 H9 CH0MTIY9 9PNI BH3N K0 B9CH9 L3 W9RN9 T3RII BH3N RUSW9 H0 G9Y9 H0G9😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 66000);
setTimeout(() => {a({body: "SUN9 H9 T3RI M9W KI ZIND9GII J9L G9Y9 M3R3 H9TH 9B T3RI M9 KI9 K9R3G9  Z9R9 B9T9 MUJ3 M3 T3RI BH3N K0 LUNG9 KI9 T3RI M99 B9CH J9YG9😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 69000);
setTimeout(() => {a({body: "SUN9 H9 T3RI BH3N RUSW9 H0 G9Y9 9B T3RI BH3N KI ZIN9 KRUNG9 N9 M3 R9NDI K9 B9CH3 Y9T33M T9T9 B9N G9Y9 T3RI MAA😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 72000);
setTimeout(() => {a({body: "SUN9 H9 T3RII M99 B9R9 R9NDI H9 M9D9R CH0DI K9RT9 H9 T3RI BH3N KI B9RW9I K9RK3 T3RI BH3N CH0DW9 L3T9 H9 MUJS3😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 75000);
setTimeout(() => {a({body: "T3R1 N1K1 9P1 K1 B0BS P9R M0T M9RU G9SHT1 K B9CH3 T3R1 M99 NU L9N M9RK3 B9CH9 N1K9LU B0SDK3 UL9D BH3N CH0D R0N9 KR TU BS CH0T1Y😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 78000);
setTimeout(() => {a({body: "0Y3 Y9T33M T3RI M99 KI CHUT R9NDII K3 B9CH3 KIDS K UL9D KISI T3XI M9W K B9CHW T3RI P9IN D9 FUD9😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 81000);
setTimeout(() => {a({body: "T3RIII 15 S9L9 BH3N KI KUS M3 L9ND SP33D S3 D9LUNG9 S39L T0T J9YG9 KH00N NIK9L J9YNG3 T3RI BH3N KI CHUT S3 M3R9 B9CH9😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 84000);
setTimeout(() => {a({body: "T3RI F9MLIY KI H9R L9RKII KI S39L TH0RUNG9  S9BK9 ZIND9GI KH9R9B H0G9 T3RI BH3N UNK0 B NHII CH0R0NG9 M3 Y9T33M😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 87000);
setTimeout(() => {a({body: "T9T9 SUN T3R9 M99 R9NDI H99 KI9 T3RI M9W KI CHUT F9TII HU33 H9 KI KUTH3 D9 B9CH9 T3RI M9W KO CHUDU😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 90000);
setTimeout(() => {a({body: "T3RI B3H3N KI CH00T M3 MAI L0WDA DUNGA B3H3N CH0UD K3 BACCH3W T3RI B3H3N KI CH00T MARUNGA BH0SDIK3 BACCH3W 😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 93000);
setTimeout(() => {a({body: " L0WD3 K3 BACCH3W T3RI B3H3N K3 BH0SD3 M3 LAAT MAAR MAAR K3R T3RI B3H3N KI CH00T K0 MAI SULA DUNGA L0WD3 K3 BACCH3W3 😆❤️]]\n\n" + " " + name, mentions: arraytag})} , 96000);
setTimeout(() => {a({body: "T3RI B3H3N KI GAAND M3 MAI HATHI KA L0WDA DAAL K3R T3RI B3H3N KI GAAND K0 CH33R DALU RANDII K3 NASHAL 😆❤️]]\n\n" + " " + name, mentions: arraytag })} , 99000);
setTimeout(() => {a({body: "L9N9T1 M9D9R CH0D K UL9DD R9ND1 K N9S9L F33L KR T3R1 N1K1 M99 NU L9N M9RU G9SHT1 K UL9DD M99 CHUDU T3R9 M9IW😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 102000);
setTimeout(() => {a({body: "Y99D K9R M9 T3R9 W0 B99P HUN J1SK0 TUJH3 T3R1 M99 NY 9J T9K N9H1 B9T9Y9 H91😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 105000);
setTimeout(() => {a({body: "T3RI B3H3N KI GAAND M3 MAI L0WDA DUNGA B3H3N CH0UD K3 DINN3 T3RI B3H3N KI CH00T K0 MAI SULA DU 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 108000);
setTimeout(() => {a({body: "T3RI MAA K3 BH0SD3 MA MAI LAAT MAAR KAR T3RI B3H3N K3 BH0SD3 K0 MAI CH33R DUNGA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 111000);
setTimeout(() => {a({body: "T3RI BAJI KI CH00T M3 MAI SUN3HRI L0WDA DAAL K3 T3RI BAAJII KI CH00T K0 KALAPA DUNGA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 114000);
setTimeout(() => {a({body: ":* T3RI B3H3N KI GAAND KA MAI W0 HAAL KRUNAG B3NCH0UD K3 DIINN3 KI T3RI B3H3N KI GAAND =DFATI KI FATI R3H JAAY3GI 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 117000);
setTimeout(() => {a({body: "T3RI T3RI B3H3N KI CH00T T0 KALAP KALAP K3 L0WDA CH00S3 JAA RHI HAI H3N H3N B3H3N CH0UD K3 DINN3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 120000);
setTimeout(() => {a({body: "SUNA HAI T3RI MAA 1 JUNGL3 MAI GAY3 THI WAHA W0 BHATAK GAY3 THI AUR KISI P0W3RFUL JANWAR N3 USKI GAAND MAI J0R S3 PANJA MAARA THA SAHI SUNA HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 123000);
setTimeout(() => {a({body: "SUNA HAI T3RI MAA HARPIC P0W3R US3 KARTI HAI IS IY3 USKI CH00T T3RI B3H3N KI CH00T S3 PAANCH_GUNAAH JYADA B3HTAR SAAF HAI :P :D SAHI SUNA HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 126000);
setTimeout(() => {a({body: "T3RI MAA K3 KUSS K0 MAI CH33R DU SUAR K3 BACCH3W T3RI B3H3N K3 BH0SD3 MA MIA FIR3 KRU 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 129000);
setTimeout(() => {a({body: "T3RI B3H3N KI CH00T K0 MAI AISA CH0UDUNGA KI T3RI B3H3N KI CH00T AAJ KALAP3GI L0WD3 K3 BAAL 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 132000);
setTimeout(() => {a({body: "T3RI MAA K0 MAI AISA CH0UDUNGA KI T3RI BAAJII KI RUH KAANP UTH3GI B3H3N CH0UD K3 DINNN3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 135000);
setTimeout(() => {a({body: "T3RI MAA KI CH00T MAI AAJ MAI N3 S0DA KI B0TTLY HILA HILA K3 KH0L K3 GHUSSAAY3 THI JAA K3 D3KH KUCH S0DA BACHI HAI WAHA T0H P33 L3 NAHI T0H WAHI R3HN3 D3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 138000);
setTimeout(() => {a({body: "T3RI B3H3N K3 D0N0 CH0CH3 K3 B33CH 1 DAANA HAI USS DAAN3 KA SIZ3 BATA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 141000);
setTimeout(() => {a({body: "ACHA SUN APNI B3H3N K3 B00BS KA M33THA M33THA RAS MALAI WAALA D00DH T0H PILA D3 MUJH3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 144000);
setTimeout(() => {a({body: "T3RI MAA KI CH00T MAI D3KH MAIN3 GARAM GARAM K0YL3 DAAL DIY3 TH3 D3KH CH00T KAALI H0WI K3 NAHI😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 147000);
setTimeout(() => {a({body: "SUNA HAI T3RI BAAJI KI CH00T S3 JAB PANI NIKALTA HAI T0U TUM SAB US S3 SUBAH FAC3 WASH K3RT3 H0 Y3 SACH HAI KYA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 150000);
setTimeout(() => {a({body: "SUNA HAI T3RA BAAP GALI0N MAI L0WDA CH00STA HAI ? Y3 SACH HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 153000);
setTimeout(() => {a({body: "SUNA HAI T3RA BAAP KACHRAA UTHAAN3 GALI GALI FIRTA HAI Y3 SACH HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 156000);
setTimeout(() => {a({body: "SUNA HAI T3RI BAAJI BH33K MANG MANG K3 APNI CH00T CHUDWATI HAI 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 159000);
setTimeout(() => {a({body: "SUNA HAI T3RI BAAJI CH00T MAI D00DH DAAL0 T0U PANI NIKALTA HAI Y3 SACH HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 162000);
setTimeout(() => {a({body: "SUNA HAI T3RI BAAJI SWIMMING K3RT3 K3RT3 SWIMMING P00L KA SAARA PAANI APNI CH00T MAI L3 GAYI THI Y3 SACH HAI KYA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 165000);
setTimeout(() => {a({body: "SUNA HAI T3RA BAAP CIGRATT3 APNI GAAND S3 P33TA HAY ? Y3 SACH HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 168000);
setTimeout(() => {a({body: "AB3 T3RI MAA KI CH00T D3KH JAA K3 ZUNG LAG GYA HAI SAAF T0H KAR LIYA KAR B3H3N K3 L0WD3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 171000);
setTimeout(() => {a({body: "SUNA HAI T3RI MAA N3 KISSI AUR S3 CHUDWA K3 TUJH3 P3DA KIYA HAY KYUNK3 T3RA BAAP KHUSRA HAI ? Y3 SACH HAI KYA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 174000);
setTimeout(() => {a({body: "AB3 T3RI MAA KI NAAK MAI 2 M3T3R LAMBI K33L GAAD DUNGA FIR T3RI MAA K0 MUHH S3 SAANS L3NA PAD3GA H33H3H3H3H3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 177000);
setTimeout(() => {a({body: "ACHA CHAL R00 MAT ACHA Y3 BATA T3RA BAAP BR3AK DANC3 K3R L3TA HAI KYA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 180000);
setTimeout(() => {a({body: "T3RI MAA KI CH00T MAI GARRAM L0HA DAAL K3 JAMA DUNGA H3H33H3H3H3H3H3H3HH T3RI MAA KI CH00T BL0CK H0 JAYGI 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 183000);
setTimeout(() => {a({body: "T3RI B3H3N KI CH00T K0 CHAAQU S3 KAAT KAR FIR TAANK3 LAGA KAR WAPIS P3HL3 JAISA KAR DUNGA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 186000);
setTimeout(() => {a({body: "T3RI MAA K3 BH0SD3 MAI TUJH3 WAAPIS GHUSS3D DUNGA BAAP S3 FADDA KAR3 GA TU H3IN😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 189000);
setTimeout(() => {a({body: "T3RI MAA KI CH00T MAI GHUSS KAR KHUJLI KARUNGA MAI USS S3 T3RI MAA K0 ACHA LAG3GA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 192000);
setTimeout(() => {a({body: "AB3 BH0SDIK3 T3RI MAA KI CH00T MAI M3THAN3 KI PIP3 DAL K3 AAG LAGA DUNGA T3RI MAA R0CK3T KI TARA UD3GI HAHAAHAHAH 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 195000);
setTimeout(() => {a({body: "T3RI MA KI GAAND M3 ITN3 L0WD3 MARUNGA USKI GAAND L0D0 KI KHAN LAG3N3 LG3GI B3H3NCH0UD😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 198000);
setTimeout(() => {a({body: "MATHRCHD K3 BACH3 SUWR K3 BACH3 T3RI MA KI GAAND M3 MUKK3 MAR K USKI GAAND SUJA DU😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 201000);
setTimeout(() => {a({body: "SAL3 T3RI MAA KI CH00T MAI MIRCHI AUR T3L GARAM KARK3 TADKA LAGA DUNGA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 204000);
setTimeout(() => {a({body: "T3RI MAA N3 TUJH3 PAIDA KARN3 S3 P3HL3 T3R3 BAAP KA 1 INCH KA L0WDA L3N3 S3 USK0 CH00T KA CANC3R H0 GYA AB MAI D0CT0R BAN K3 T3RI MAA KI CH00T KA ILAAJ KARUNGA 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 207000);
setTimeout(() => {a({body: "T3RI MAA KI CH00T MAI AATANKWADI0 S3 NISHAAN3 LAGWAUNGA B3 BH0SDIK3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 210000);
setTimeout(() => {a({body: "SAL3 CHTIY3 K3 BACH3 CHUDAKAD KH0R  KI AUALD  HRAM K3 PIL3  M3RA L0WDA CHOOS3GA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 213000);
setTimeout(() => {a({body: "CH00T MARI K3 DIN3  T3RI B3H3N KA RAP3 KARUNGA BHARI M3TR0 M3 L3 JA K3 MA K3 LUND😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 216000);
setTimeout(() => {a({body: "T3RI MA K3 KAL3 BH00SD3 M3 B0MB F0D K3 BLAST KRVA DUNGA MATHRCHD K3 BACH3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 219000);
setTimeout(() => {a({body: "CHINAL K3 PIL3  K0TH3 VALI RANDI K3 IKL0T3 KUTIYA K3 BACH3 B3H3NCH0UD K3 DIN3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 222000);
setTimeout(() => {a({body: "T3RI MA K3 BH0SD3 M3 APN3 LUND S3 USK3 BH0SD3 K0 KHULA KAR DUNGA SAL3 CHAMR😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 225000);
setTimeout(() => {a({body: "MATHRCHD K3 BACH3 CHUD3 HU3 TATT3 YHA APNI MA K0 CHUDAN3 AYA THA MA K3 LUND😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 228000);
setTimeout(() => {a({body: "MA K3 LUND  T3RI B3H3N KI CH0TI CH00T M3 APN3 L0WD3 K0 DAL K3 USKI CH00T KH0LU😆❤️]]😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 231000);
setTimeout(() => {a({body: "T3RI MA K3 BH0SD3 M3 CURRNT LAGA K3 USK3 BHS0D3 M3 S3 BACH3 PAIDA KAR DUNGA😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 234000);
setTimeout(() => {a({body: "T3RI MA KI GAAND M3 SAND KA LULLA FASA DU BH0SDI K3 DAL33T K3 BACH3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 237000);
setTimeout(() => {a({body: "MA K3 LUND B3TICH0UD K3 BACH3 T3RI MA K3 BH0SD3 K0 CH33R K3 RKH DU SAL3 GAAND😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 240000);
setTimeout(() => {a({body: "T3RI MA K3 BH0SD3 M3 THPAD DUNGA SAL3 GHANDV3 K3 BADCH3 B3H3NCH0UD K3 DIN3😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 243000);
setTimeout(() => {a({body: "T3RIIW M9W K9W KUS99 M9RUU D9LII M99W DY99 B9CHY99 S9LY99 Y9T33M K99W B9CH99W 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 246000);
setTimeout(() => {a({body: "OY3 T3RII 9MII K9W KUS99 M99R K99R NIL99M K9RUU D9LII K99W B9 H9😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 249000);
setTimeout(() => {a({body: "0Y3 T3RIW M9W KIW CHUD9IIW KR9W KSIIW R9NDIIW K3 B9CH3 BH3N K3 L0D3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 252000);
setTimeout(() => {a({body: "0Y3 T3RIW M9W K3 PHUD3 Y9W99 K3 KISII G9SHTIW K9W B9CH9W M9RSIIW K3 PIL3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 255000);
setTimeout(() => {a({body: "0Y3 KSII R9NDIIW K9W B9CH9W BH3N K4 L0D3 G9ND K4 GUS J9N9W T3RIW M9W 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 258000);
setTimeout(() => {a({body: "T3RII M0SII KII CH00T M9IIW LUNRR K9RUU D9LII DY99 B9CHY99 OK99TT L3SS MIKYY T9TY999 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 261000);
setTimeout(() => {a({body: "T9RIIW M9W KIW KUS K3TRIN99W K3F K3 B9CH3 G9NDUW N9SN9W M9TTW 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 264000);
setTimeout(() => {a({body: "Y9W99 K3 M9DRCH0D K3 B9CH3 SL0W T9T3 G9NDUUW KIW UL9DW T3RIIW BH3N K0W T9W9IF B9N9W K3 P3L9 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 267000);
setTimeout(() => {a({body: "OY3 TERIIW M9W K3 BH0SR3 K3 9GH LG9W K3 BH9G J90W S9L3 JH9T K3 B9R9B9R K3 T9T3 L0C9LL K9T0R3 M9RSII K3 B9CH3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 270000);
setTimeout(() => {a({body: "0Y3 T3RIIW M99W K3 MUHW M3 S9RIY9W D9LW K3 USKIW MUH KIW H9L9T BURI8W KR9W S9ST3 T9T3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 273000);
setTimeout(() => {a({body: "T3RII B3HN99 KII KUSS TY LITH3RR M9R99N D9LII DY99 B9CHY99 S9LY99 G9SHTII K9WW B9CHO9😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 276000);
setTimeout(() => {a({body: "T3RII B3HN99 KII CH0TIU CH00T M9IIW LUNDD M9RUU KH0TII K99WW B9CH99 OK99TT BN99W T9T9 JIIW 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 279000);
setTimeout(() => {a({body: "0Y3 KSII KUTIW K3 KUT3 S3 B9CH3 G9ND K9W Z0R LG9W G9WRR T9T3W 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 282000);
setTimeout(() => {a({body: "T3RII M0SII KII GUL9BII CH00TT M9IIW LUNDD M9RUU D9LII D799 B9CHY99  OK99TT L3SSS T9TY99😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 285000);
setTimeout(() => {a({body: "T3RII B3HN99 K9WW ZIN99 K9RUU G9WRRR Y9T33M K9WW KUS99 M9RUU D9LII DY99 B9CHY99 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 288000);
setTimeout(() => {a({body: "T3RII T9XII M99WW KII K9LII M0TII PHUDIIW M9IIW LUNDD K9RUU D9LII DY99 B9CHY99 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 291000);
setTimeout(() => {a({body: "0Y3 KSII G9WRR K3 Y9T3MM T9T3 BH3N KIW KUS T3RIIW KIIW S9L3 S9ST3 PIL3 BSDK K3 B9CH3 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 294000);
setTimeout(() => {a({body: "T3RII M0SII K9WW S9NJ99 M9NJ99 M9RUU G9WRR KH0TII K9WW B9CH99 S9L99 L0WW L3VLL Y9T33M 😆❤️]]\n\n" + " " + name, mentions: arraytag })}, 297000);
  setTimeout(() => {a({body: "CHALLL BYEE BEHENN KEE LOOREE TERAA BAAAP JA RAHA HAII AB PITH PICHEE BHOKNAA MATT OKKK 🐥🙊🙊" + name, mentions: arraytag})},300000);
}